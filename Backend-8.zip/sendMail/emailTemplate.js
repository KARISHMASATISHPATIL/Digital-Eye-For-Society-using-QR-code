const Sib = require('sib-api-v3-sdk')
const client = Sib.ApiClient.instance
const apiKey = client.authentications['api-key']
// apiKey.apiKey = "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"
apiKey.apiKey = "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"
const tranEmailApi = new Sib.TransactionalEmailsApi();

const sendMail = (userEmail, name, contact, area, street, taluka, dist, zip, propertyTax, waterTax, landArea, landRate, status) => {
    const sender = {
        email: 'cms.department1@gmail.com',
        name: 'Munciple Corporation',
    }

    const receivers = [
        {
            email: userEmail,
        },
    ]
    tranEmailApi
        .sendTransacEmail({
            sender,
            to: receivers,
            subject: 'Property Tax Payment Due',
            textContent:
            `
                <h2 style="color: #333333;">Important: Property Deatails and Tax Payment Reminder</h2>
                <p>I hope this email finds you well. I am writing to inform you about the property registration. Your property has been registered successfully. Requesting you to please pay the tax added on the registered property. It is important to ensure timely payment to avoid any unnecessary penalties or late fees. Below are the details regarding your property and tax:</p>
                <p>Dear ${name},</p>
                <strong>Email: ${userEmail}</strong>
                <strong>Contact: ${contact}</strong>
                <strong>Area: ${area}</strong>
                <strong>Street: ${street}</strong>
                <strong>Taluka: ${taluka}</strong>
                <strong>District: ${dist}</strong>
                <strong>Zip Code: ${zip}</strong>
                <strong>Property Area: ${landArea} sq ft </strong>
                <strong>Property Rate: ₹ ${landRate}</strong>
                <strong>Property Tax Amount: ₹ ${propertyTax}</strong>
                <strong>Water Tax Amount: ₹ ${waterTax}</strong>
                <strong>Status: ${status}</strong>
                <strong>Due Day:30 days</strong>
                <br/>
                <strong>Best regards,</strong>
                <strong>Munciple Corporation</strong>
            `,
        })
        .then(console.log)
        .catch(console.log)

}
module.exports = {
    sendMail
}