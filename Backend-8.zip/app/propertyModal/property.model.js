module.exports = mongoose => {
  var schema = mongoose.Schema(
    {
      fname: String,
      lname: String,
      contact: Number,
      email: String,
      password: String,
      gender: String,
      area: String,
      street: String,
      dist: String,
      taluka: String,
      villageType : String,
      zip : String,
      propertyType : String,
      landRate : String,
      landArea : String,
      ownership: String,
      propertyTax:String,
      waterTax:String,
      liveProperty:String,
      landBuilding:String,
      status:String,
      qrFlag:String
    },
    { timestamps: true }
  );

  schema.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });

  const Property = mongoose.model("property", schema);
  return Property;
};
