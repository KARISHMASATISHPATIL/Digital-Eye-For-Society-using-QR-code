const dbConfig = require("../config/db.config.js");

const mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const db = {};
db.mongoose = mongoose;
db.url = dbConfig.url;
db.userDetails = require("./user.model.js")(mongoose);
db.propertyDetails = require("../propertyModal/property.model.js")(mongoose);
module.exports = db;
