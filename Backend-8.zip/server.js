const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const bcrypt = require("bcrypt");
const nodemailer = require('nodemailer')
const app = express();

var options = {
  origin: "*",
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  preflightContinue: false,
  optionsSuccessStatus: 204,
};

app.use(cors(options));

// parse requests of content-type - application/json
app.use(bodyParser.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

const db = require("./app/userModal");
const { sendMail } = require("./sendMail/emailTemplate");
const { sendMailPay } = require("./sendMailPay/emailTemplatePay");
const { sendMailVerify } = require("./sendMailVerify/emailTemplatePay");
const User = db.userDetails
const Property = db.propertyDetails

db.mongoose
  .connect(db.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    console.log("Connected to the database!");
  })
  .catch(err => {
    console.log("Cannot connect to the database!", err);
    process.exit();
  });

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to bezkoder application." });
});

//login
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    let users = await User.findOne({ email, password });
    console.log('users',users);
    if(users?.verify === 'Verify') return res.status(400).send("User is not verified");
    else if (!users) return res.status(400).send("Please check your email and password");
    const validPassword = await users.password;
    if (!validPassword) return res.status(400).send("Please enter a valid password.");
    //at this point, login is successfull, return the user info without the password info
    users.password = undefined;
    res.send(users);
  } catch (err) {
    console.log(err);
    res.status(500).send("Something went wrong");
  }
});

//admin login
app.post("/admin/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    let user = await Admin.findOne({ email, password });
    if (!user) return res.status(400).send("User not found");
    const validPassword = await user.password;
    if (!validPassword) return res.status(400).send("Please enter a valid password.");
    //at this point, login is successfull, return the user info without the password info
    user.password = undefined;
    res.send(user);
  } catch (err) {
    console.log(err);
    res.status(500).send("Something went wrong");
  }
});

//register
app.post("/register", (req, res) => {
  User.create({
    fname: req.body.fname,
    lname: req.body.lname,
    contact: req.body.contact,
    email: req.body.email,
    password: req.body.password,
    gender: req.body.gender,
    verify: "Verify"
  })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Tutorial."
      });
    });
});

app.put("/verify/:id", async (req, res) => {
  User.findByIdAndUpdate(
    req.params.id,
    { $set: { 'verify': req.body.verify } },
    { new: true },
    function (err, result) {
      console.log('result', result);
      if (err) {
        console.log(err);
      }
      res.json(result);
    }
  );
});

//DonorInfo User List
app.route("/user-list").get(function (req, res) {
  User.find({}, function (err, result) {
    if (err) {
      console.log(err);
    } else {
      res.json(result);
    }
  });
});



//Property add
app.post("/property-add", (req, res) => {
  Property.create({
    fname: req.body.fname,
    lname: req.body.lname,
    contact: req.body.contact,
    email: req.body.email,
    gender: req.body.gender,
    area: req.body.area,
    street: req.body.street,
    ownership: req.body.ownership,
    liveProperty: req.body.liveProperty,
    landBuilding: req.body.landBuilding,
    status: req.body.status,
    dist: req.body.dist,
    taluka: req.body.taluka,
    zip: req.body.zip,
    villageType: req.body.villageType,
    propertyType: req.body.propertyType,
    landRate: req.body.landRate,
    landArea: req.body.landArea,
    propertyTax:req.body.propertyTax,
    waterTax:req.body.waterTax,
    qrFlag: 'Pending',
  })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Tutorial."
      });
    });
});

app.route("/property-list").get(function (req, res) {
  Property.find({}, function (err, result) {
    if (err) {
      console.log(err);
    } else {
      res.json(result);
    }
  });
});

//updates status in property page (invoice)
app.put("/status-update/:id", async (req, res) => {
  Property.findByIdAndUpdate(
    req.params.id,
    { $set: { 'status': req.body.status } },
    { new: true },
    function (err, result) {
      console.log('result', result);
      if (err) {
        console.log(err);
      }
      res.json(result);
    }
  );
});

app.put("/qrflag-update/:id", async (req, res) => {
  Property.findByIdAndUpdate(
    req.params.id,
    { $set: { 'qrFlag': req.body.qrFlag } },
    { new: true },
    function (err, result) {
      console.log('result', result);
      if (err) {
        console.log(err);
      }
      res.json(result);
    }
  );
});

//updates status in property page (invoice)
app.put("/tax-update/:id", async (req, res) => {
  Property.findByIdAndUpdate(
    req.params.id,
    { $set: req.body },
    { new: true },
    function (err, result) {
      console.log('result', result);
      if (err) {
        console.log(err);
      }
      res.json(result);
    }
  );
});

//updates status in property page (invoice)
app.put("/amount-update/:id", async (req, res) => {
  Property.findByIdAndUpdate(
    req.params.id,
    { $set: req.body },
    { new: true },
    function (err, result) {
      console.log('result', result);
      if (err) {
        console.log(err);
      }
      res.json(result);
    }
  );
});

app.post('/sendMail', (req, res) => {
  const { userEmail, name, contact, area, street, taluka, dist, zip, propertyTax, waterTax, landArea, landRate, status } = req.body
  try {
    sendMail(userEmail, name, contact, area, street, taluka, dist, zip, propertyTax, waterTax, landArea, landRate, status)
    res.status(200).send({ message: 'Mail Sent' })
  } catch (error) {
    res.status(500).send({ error })
  }
})

app.post('/sendMailPay', (req, res) => {
const { userEmail, name, contact, area, street, taluka, dist, zip, propertyTax, waterTax, landArea, landRate, status } = req.body
  try {
    sendMailPay(userEmail, name, contact, area, street, taluka, dist, zip, propertyTax, waterTax, landArea, landRate, status )
    res.status(200).send({ message: 'Mail Sent' })
  } catch (error) {
    res.status(500).send({ error })
  }
})

app.post('/sendMailVerify', (req, res) => {
  const { userEmail, name, password} = req.body
    try {
      sendMailVerify(userEmail, name, password)
      res.status(200).send({ message: 'Mail Sent' })
    } catch (error) {
      res.status(500).send({ error })
    }
  })

// require("./app/routes/turorial.routes")(app);

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
