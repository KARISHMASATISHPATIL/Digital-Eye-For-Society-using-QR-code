const Sib = require('sib-api-v3-sdk')
const client = Sib.ApiClient.instance
const apiKey = client.authentications['api-key']
apiKey.apiKey = "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"

const tranEmailApi = new Sib.TransactionalEmailsApi();

const sendMailPay = (userEmail, name, contact, area,street, taluka, dist, zip, propertyTax, waterTax, landArea, landRate, status ) => {
    const sender = {
        email: 'cms.department1@gmail.com',
        name: 'Munciple Corporation',
    }

    const receivers = [
        {
            email: userEmail,
        },
    ]

    tranEmailApi
        .sendTransacEmail({
            sender,
            to: receivers,
            subject: 'Property Details',
            textContent:
            `
                <h2 style="color: #333333;">Important: Property Registation details and payment status</h2>
                <p>Hi ${name}! We're excited to share the register details of the property and tax payment status,</p>
                <strong>Email: ${userEmail}</strong>
                <strong>Contact: ${contact}</strong>
                <strong>area: ${area}</strong>
                <strong>street: ${street}</strong>
                <strong>Taluka: ${taluka}</strong>
                <strong>District: ${dist}</strong>
                <strong>Zip Code: ${zip}</strong>
                <strong>Property Area: ${landArea} sq ft </strong>
                <strong>Property Rate: ₹ ${landRate}</strong>
                <strong>Property Tax Amount: ₹ ${propertyTax}</strong>
                <strong>Water Tax Amount: ₹ ${waterTax}</strong>
                <strong>Status: ${status}</strong>
                <br/>
                <strong>Best regards,</strong>
                <strong>Munciple Corporation</strong>
            `,
        })
        .then(console.log)
        .catch(console.log)

}
module.exports = {
    sendMailPay
}