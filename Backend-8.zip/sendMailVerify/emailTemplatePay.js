const Sib = require('sib-api-v3-sdk')
const client = Sib.ApiClient.instance
const apiKey = client.authentications['api-key']
apiKey.apiKey = "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"

const tranEmailApi = new Sib.TransactionalEmailsApi();

const sendMailVerify = (userEmail, name, password ) => {
    const sender = {
        email: 'cms.department1@gmail.com',
        name: 'Munciple Corporation',
    }

    const receivers = [
        {
            email: userEmail,
        },
    ]

    tranEmailApi
        .sendTransacEmail({
            sender,
            to: receivers,
            subject: 'User verification',
            textContent:
            `
                <h2 style="color: #333333;">Important: User registration verified successfully here are user creditials</h2>
                <h1> </h1>
                <strong>Email: ${userEmail}</strong>
                <strong>Password: ${password}</strong>
                <br/>
                <strong>Best regards,</strong>
                <strong>Munciple Corporation</strong>
            `,
        })
        .then(console.log)
        .catch(console.log)

}
module.exports = {
    sendMailVerify
}