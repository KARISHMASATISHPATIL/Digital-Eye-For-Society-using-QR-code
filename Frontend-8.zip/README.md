# Install

## React code challenge

This application presents views of files from the GiphyAPI. The code challenge makes amendments to react/src/components/Header.jsx file

### Requirements

1. Node version 19

If using [nvm](https://www.sitepoint.com/quick-tip-multiple-versions-node-nvm/)

```
nvm install 19
nvm use 19
```

2. npm

### Set up

Install dependencies - $ `npm  install`

### Running the App & Tests

To run the application (from the react folder)

```
npm run dev
```

And open a browser at http://localhost:3000

