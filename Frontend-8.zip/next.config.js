module.exports = {
  reactStrictMode: true,
  async redirects() {
    return [{
      source: '/auth/login',
      destination: '/login',
      permanent:true
    }
    ]
  }
};
