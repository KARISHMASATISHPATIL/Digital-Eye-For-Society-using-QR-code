import Head from 'next/head';
import { subDays, subHours } from 'date-fns';
import { Box, Container, Unstable_Grid2 as Grid } from '@mui/material';
import { Layout as DashboardLayout } from 'src/layouts/dashboard/layout';
import UserRegistartion from './user-registration';
import UserTable from './user-table';
import { useAuthContext } from 'src/contexts/auth-context';
import { useRouter } from 'next/navigation';
const Page = () => {
  const { isAuthenticated } = useAuthContext();
  const router = useRouter()
  const logingFlag = localStorage.getItem('logingFlag')
  console.log('logingFlag',logingFlag);
  return(
  <>
    <Head>
      <title>
        Munciple Corporation
      </title>
    </Head>
    {!isAuthenticated && (!logingFlag || logingFlag === undefined || logingFlag === null) ? router.push('auth/login') : !isAuthenticated ? <UserRegistartion/> : <UserTable />}
  </>
  )
}

Page.getLayout = (page) => (
  <DashboardLayout>
    {page}
  </DashboardLayout>
);

export default Page;
