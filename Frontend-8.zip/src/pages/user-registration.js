import { Box, Container, Stack, Typography, Unstable_Grid2 as Grid } from '@mui/material';
import { Layout as DashboardLayout } from 'src/layouts/dashboard/layout';
import { AccountProfileDetails } from 'src/sections/account/account-profile-details';

const Page = () => (
    <>
        <Box
            component="main"
            sx={{
                display: 'flex',
                flex: '1 1 auto',
            }}
        >

            <Grid
                xs={12}
                lg={6}
                sx={{
                    backgroundColor: 'background.paper',
                    display: 'flex',
                    flexDirection: 'column',
                    position: 'relative'
                }}
            >
                <Box
                    component="header"
                    sx={{
                        left: 0,
                        p: 3,
                        position: 'fixed',
                        top: 0,
                        width: '100%'
                    }}
                >
                </Box>
                <Stack spacing={3}>
                    <div>
                        <Typography variant="h4" align='center'>
                            User Registraion
                        </Typography>
                    </div>
                    <div>
                        <Grid
                            container
                            spacing={3}
                        >
                            <Grid
                                xs={12}
                                md={6}
                                lg={12}
                            >
                                <AccountProfileDetails />
                            </Grid>
                        </Grid>
                    </div>
                </Stack>
            </Grid>
            <Grid
                xs={12}
                lg={6}
                sx={{
                    alignItems: 'center',
                    background: 'radial-gradient(50% 50% at 50% 50%, #122647 0%, #090E23 100%)',
                    color: 'white',
                    display: 'flex',
                    justifyContent: 'center',
                    '& img': {
                        maxWidth: '100%'
                    }
                }}
            >
              {/*   <Box sx={{ p: 3 }}>
                    <Typography
                        align="center"
                        color="inherit"
                        sx={{
                            fontSize: '24px',
                            lineHeight: '32px',
                            mb: 1
                        }}
                        variant="h1"
                    >
                        <Box
                            component="a"
                            sx={{ color: '#15B79E' }}
                            target="_blank"
                        >
                            User Datails
                        </Box>
                    </Typography>
                    <img
                        alt=""
                        src="/assets/auth-illustration.svg"
                    />
                </Box> */}
            </Grid>
        </Box>
    </>
);

Page.getLayout = (page) => (
    <DashboardLayout>
        {page}
    </DashboardLayout>
);

export default Page;
