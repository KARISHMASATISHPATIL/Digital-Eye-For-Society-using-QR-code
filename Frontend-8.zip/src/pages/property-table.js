import { useCallback, useEffect, useMemo, useState } from 'react';
import Head from 'next/head';
import { Box, Container, Stack, SvgIcon, Typography } from '@mui/material';
import { useSelection } from 'src/hooks/use-selection';
import { Layout as DashboardLayout } from 'src/layouts/dashboard/layout';
import { applyPagination } from 'src/utils/apply-pagination';
import axios from 'axios';
import Swal from 'sweetalert2';
import { PropertyTable } from 'src/sections/property-details/property-table';

const useCustomers = (data, page, rowsPerPage) => {
  return useMemo(
    () => {
      return applyPagination(data, page, rowsPerPage);
    },
    [page, rowsPerPage]
  );
};

const useCustomerIds = (customers) => {
  return useMemo(
    () => {
      return customers.map((customer) => customer.id);
    },
    [customers]
  );
};

const Page = () => {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  
  const [data, setData] = useState([])

  useEffect(()=> {
      axios.get('http://localhost:8080/property-list').then(res => {
          setData(res?.data)
      }).catch(error => {
          Swal.fire({
              timer: 1500,
              showConfirmButton: false,
              willOpen: () => {
                Swal.showLoading();
            },
              willClose: () => {
                Swal.fire({
                  icon: 'error',
                  title: 'Error!',
                  text: error?.response?.data,
                  showConfirmButton: true,
                });
              },
            });
      })
  },[])
  
  const customers = useCustomers(data, page, rowsPerPage);
  const customersIds = useCustomerIds(customers);
  const customersSelection = useSelection(customersIds);
  
  const handlePageChange = useCallback(
    (event, value) => {
        setPage(value);
    },
    []
    );
    
  const handleRowsPerPageChange = useCallback(
    (event) => {
      setRowsPerPage(event.target.value);
    },
    []
  );

  return (
    <>
      <Head>
        <title>
          Property | Munciple Corporation
        </title>
      </Head>
      <Box
            component="main"
            sx={{
                display: 'flex',
                flex: '1 1 auto',
            }}
        >
        <Container maxWidth="xl">
          <Stack spacing={3}>
            <Stack
              direction="row"
              justifyContent="space-between"
              spacing={4}
            >
              <Stack spacing={1}>
                <Typography variant="h4">
                 Property Table
                </Typography>
              </Stack>
            </Stack>
            {/* <PropertySearch /> */}
            <PropertyTable
              count={data.length}
              items={data}
              onPageChange={handlePageChange}
              onRowsPerPageChange={handleRowsPerPageChange}
              page={page}
              rowsPerPage={rowsPerPage}
              selected={customersSelection.selected}
            />
          </Stack>
        </Container>
      </Box>
    </>
  );
};

Page.getLayout = (page) => (
  <DashboardLayout>
    {page}
  </DashboardLayout>
);

export default Page;
