import PropTypes from 'prop-types';
import NextLink from 'next/link';
import { Box, Typography, Unstable_Grid2 as Grid } from '@mui/material';
import { Logo } from 'src/components/logo';

// TODO: Change subtitle text

export const Layout = (props) => {
  const { children } = props;

  return (
    <Box
      component="main"
      sx={{
        display: 'flex',
        flex: '1 1 auto'
      }}
    >
      <Grid
        container
        sx={{ flex: '1 1 auto' }}
      >
        <Grid
          xs={12}
          lg={6}
          sx={{
            backgroundColor: 'background.paper',
            display: 'flex',
            flexDirection: 'column',
            position: 'relative'
          }}
        >
          <Box
            component="header"
            sx={{
              left: 0,
              p: 3,
              position: 'fixed',
              top: 0,
              width: '100%'
            }}
          >
          </Box>
          {children}
        </Grid>
        <Grid
          xs={12}
          lg={6}
          sx={{
            alignItems: 'center',
            background: 'radial-gradient(50% 50% at 50% 50%, #122647 0%, #090E23 100%)',
            color: 'white',
            display: 'flex',
            justifyContent: 'center',
            '& img': {
              maxWidth: '100%'
            }
          }}
        >
          <Box sx={{ p: 3 }}>
            <Typography
              align="center"
              color="inherit"
              sx={{
                fontSize: '24px',
                lineHeight: '32px',
                mb: 1
              }}
              variant="h1"
            >
              Welcome to{' '}
              <Box
                component="a"
                sx={{ color: '#15B79E' }}
                target="_blank"
              >
                Munciple Corporation
              </Box>
            </Typography>
            <div align='center' >
              <img
               style={{
                display: 'inline-block',
                maxWidth: '40%',
                width: 400
              }}
                alt=""
                src="/assets/logo-munciple.jpeg"
              />
            </div>
            <Typography
              align="center"
              color="inherit"
              sx={{
                fontSize: '16px',
                lineHeight: '32px',
                mb: 1
              }}
              variant="h6"
            >
              Shahade is a Municipal Council city in district of Nandurbar, Maharashtra. The Shahade city is divided into 24 wards for which elections are held every 5 years. The Shahade Municipal Council has population of 61,376 of which 31,414 are males while 29,962 are females as per report released by Census India 2011.
            </Typography>

            <Typography
              align="center"
              color="inherit"
              sx={{
                fontSize: '14px',
                lineHeight: '32px',
                mb: 1
              }}
              variant="h6"
            >
              Population of Children with age of 0-6 is 7948 which is 12.95 % of total population of Shahade (M Cl). In Shahade Municipal Council, Female Sex Ratio is of 954 against state average of 929. Moreover Child Sex Ratio in Shahade is around 906 compared to Maharashtra state average of 894. Literacy rate of Shahade city is 86.62 % higher than state average of 82.34 %. In Shahade, Male literacy is around 90.67 % while female literacy rate is 82.40 %.
            </Typography>

          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

Layout.prototypes = {
  children: PropTypes.node
};