import PropTypes from 'prop-types';
import { format } from 'date-fns';
import {
  Avatar,
  Box,
  Button,
  Card,
  Checkbox,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography
} from '@mui/material';
import { Scrollbar } from 'src/components/scrollbar';
import { getInitials } from 'src/utils/get-initials';
import axios from 'axios';
import Swal from 'sweetalert2';
import { useForceUpdate } from 'src/hooks/use-forceupdate';

export const CustomersTable = (props) => {
  const {
    count = 0,
    items = [],
    onPageChange = () => { },
    onRowsPerPageChange,
    page = 0,
    rowsPerPage = 0,
    selected = []
  } = props;

  const forceUpdate = useForceUpdate()
  const handleVerifyUser = (cust) => {
    axios.put(`http://localhost:8080/verify/${cust?.id}`,
      {
        verify: 'Verified'
      })
      .then(res => {
        axios.post(`http://localhost:8080/sendMailVerify`, {
          userEmail: res?.data?.email,
          name: res?.data?.fname + ' ' + res?.data?.lname,
          password: res?.data?.password
        })
        Swal.fire({
          timer: 1500,
          showConfirmButton: false,
          willOpen: () => {
            Swal.showLoading();
          },
          willClose: () => {
            Swal.fire({
              icon: 'success',
              title: 'User Verification Successfully',
              showConfirmButton: false,
              timer: 2500,
            });

            items?.map((it) => {
              if (res?.data?.id === it?.id) {
                it.verify = res?.data?.verify
              }
              return it
            })
            forceUpdate()
          },
        });
      })
  }


  return (
    <Card>
      <Scrollbar>
        <Box sx={{ minWidth: 800 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  First Name
                </TableCell>
                <TableCell>
                  Last Name
                </TableCell>
                <TableCell>
                  Email
                </TableCell>
                <TableCell>
                  Phone
                </TableCell>
                <TableCell>
                  Verify User
                </TableCell>
                <TableCell>
                  Created At
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {items.map((customer) => {
                const isSelected = selected.includes(customer.id);
                const createdAt = format(new Date(customer?.createdAt), 'dd/MM/yyyy hh:mm:ss');
                return (
                  <TableRow
                    hover
                    key={customer.id}
                    selected={isSelected}
                  >
                    <TableCell>
                      <Stack
                        alignItems="center"
                        direction="row"
                        spacing={2}
                      >
                        <Avatar src={customer.avatar}>
                          {getInitials(customer.fname)}
                        </Avatar>
                        <Typography variant="subtitle2">
                          {customer.fname}
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell>
                      {customer.lname}
                    </TableCell>
                    <TableCell>
                      {customer.email}
                    </TableCell>
                    <TableCell>
                      {customer.contact}
                    </TableCell>
                    {customer?.verify === 'Verified' ?
                      <TableCell
                        sx={{ cursor: 'pointer', pointerEvents: 'none' }}>
                        <Button variant="outlined" disabled>
                          Verified
                        </Button>
                      </TableCell>
                      :
                      <TableCell
                        sx={{ cursor: 'pointer' }}>
                        <Button variant="outlined" onClick={() => handleVerifyUser(customer)}>
                          Verify
                        </Button>
                      </TableCell>
                    }
                    <TableCell>
                      {createdAt}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Box>
      </Scrollbar>
      {/*   <TablePagination
        component="div"
        count={count}
        onPageChange={onPageChange}
        onRowsPerPageChange={onRowsPerPageChange}
        page={page}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={[5, 10, 25]}
      /> */}
    </Card>
  );
};

CustomersTable.propTypes = {
  count: PropTypes.number,
  items: PropTypes.array,
  onPageChange: PropTypes.func,
  onRowsPerPageChange: PropTypes.func,
  page: PropTypes.number,
  rowsPerPage: PropTypes.number,
  selected: PropTypes.array
};
