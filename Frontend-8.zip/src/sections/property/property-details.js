import { useCallback, useEffect, useState } from "react";
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Divider,
  TextField,
  Radio,
  Unstable_Grid2 as Grid,
  FormControl,
  FormLabel,
  FormControlLabel,
  RadioGroup,
  Typography,
  Select,
  MenuItem,
  InputLabel,
} from "@mui/material";
import Swal from "sweetalert2";
import axios from "axios";
import { useAuth } from "src/hooks/use-auth";
import { useRouter } from "next/navigation";
import SimpleReactValidator from "simple-react-validator";
import { useForceUpdate } from "src/hooks/use-forceupdate";

export const PropertyDetails = () => {
  const [validator] = useState(new SimpleReactValidator());
  const forceUpdate = useForceUpdate();
  const auth = useAuth();
  const router = useRouter();
  const [data, setData] = useState({
    fname: auth?.user?.fname,
    lname: auth?.user?.lname,
    email: auth?.user?.email,
    contact: auth?.user?.contact,
    gender: auth?.user?.gender,
    street: "",
    area: "",
    dist: "",
    taluka: "",
    zip:"",
    // village: '',
    propertyType: "",
    landRate: "",
    landArea: "",
    type_of_ownership: "",
    liveProperty: "",
    status: "Pending",
    propertyTax:"",
    waterTax:""
  });
  const [selectedOption, setSelectedOption] = useState(
    auth?.user?.gender ? auth?.user?.gender : "male"
  );
  const [selectedOptionLive, setSelectedOptionLive] = useState("no");
  const [selectedOptionVillageType, setSelectedOptionVillageType] =
    useState("Urban");
  const handle = {
    change: (value, name) => {
      setData({
        ...data,
        [name]: value,
      });
    },
    handleOptionChange: (e) => {
      setSelectedOption(e.target.value);
    },
    handleOptionChangeLive: (e) => {
      setSelectedOptionLive(e.target.value);
    },
    handleOptionChangeVillageType: (e) => {
      setSelectedOptionVillageType(e.target.value);
    },
    handleRegister(e) {
      e.preventDefault();
      console.log('data',data);

      if (validator.allValid()) {
        let param = {
          ...data,
          liveProperty: selectedOptionLive,
          villageType: selectedOptionVillageType,
        };
        axios
          .post(`http://localhost:8080/property-add`, param)
          .then((res) => {
            Swal.fire({
              timer: 1500,
              showConfirmButton: false,
              willOpen: () => {
                Swal.showLoading();
              },
              willClose: () => {
                Swal.fire({
                  icon: "success",
                  title: "Property Registration Successful",
                  showConfirmButton: false,
                  timer: 1500,
                });
                router.push("/property-single");
                validator.hideMessages();
              },
            });
            setData({
              fname: auth?.user?.fname,
              lname: auth?.user?.lname,
              email: auth?.user?.email,
              contact: auth?.user?.contact,
              gender: auth?.user?.gender,
              street: "",
              area: "",
              type_of_ownership: "",
              liveProperty: "",
              timeFrame: "",
              dist: "",
              taluka: "",
              zip:"",
            });
            router.push("/property-single");
            axios.get("http://localhost:8080/property-list").then((res) => {
              setData(res?.data);
            });
          })
          .catch((error) => {
            Swal.fire({
              timer: 1500,
              showConfirmButton: false,
              willOpen: () => {
                Swal.showLoading();
              },
              willClose: () => {
                Swal.fire({
                  icon: "success",
                  title: "Property Registration Successful!",
                  showConfirmButton: false,
                  timer: 1500,
                });
                router.push("/property-single");
                validator.hideMessages();
              },
            });
            axios.get("http://localhost:8080/property-list").then((res) => {
              setData(res?.data);
            });
          });
      } else {
        validator.showMessages();
        forceUpdate();
      }
    },
  };

  const percentageCalculator = (amount) => { 
    let res = ((5 * amount) / 100);
    return res
  }

  useEffect(()=> {
    let addData = {
      dist: "Nandurbar",
      taluka:"Shahada",
      zip:"425409"
    }

    switch (data?.area) {
      case "Vrudavan Nagar":

        setData({
          ...data,
          ...addData,
          street: "Dongargaon Road",
          landRate: selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 200 : data.landArea * 200,
          propertyTax: percentageCalculator(data.landRate),
          waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
        })
        break;
        case "Sambhaji Nagar":
          setData({
            ...data,
            ...addData,
            street: "Prakasha Road",
            landRate: selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 120 : data.landArea * 120,
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
          })
          break;
          case "Mira Nagar":
          setData({
            ...data,
            ...addData,
            street: "Prakasha Road",
            landRate:selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 120 :  data.landArea * 120,
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
          })
          break;
          case "Ganesh Nagar":
          setData({
            ...data,
            ...addData,
            street: "Mohida Road",
            landRate:selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 120 :  data.landArea * 120,
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
          })
          break;
          case "Shree Ram Nagar":
          setData({
            ...data,
            ...addData,
            street: "Khetiya Road",
            landRate: selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 190 : data.landArea * 190, 
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
           
          })
          break;
          case "Gujar Galli":
          setData({
            ...data,
            ...addData,
            street: "Market Road",
            landRate: selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 200 : data.landArea * 200,
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0

           
          })
          break;
          case "Bramhashrushti Colony":
          setData({
            ...data,
            ...addData,
            street: "Old Mohida Road",
            landRate:selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 180 :  data.landArea * 180,
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0

           
          })
          break;
          case "Mangalmurti Nagar":
          setData({
            ...data,
            ...addData,
            street: "Dongargaon Road",
            landRate:selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 140 :  data.landArea * 140,
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
          })
          break;
          case "Mahalaxmi Nagar":
          setData({
            ...data,
            ...addData,
            street: "Maloni Road",
            landRate:selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 150 :  data.landArea * 150, 
            propertyTax: percentageCalculator(data.landRate),
            waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
          })
          break;
          case "Punaji Nagar":
            setData({
              ...data,
              ...addData,
              street: "Lonkheda Bypass",
              landRate:selectedOptionLive === 'yes' ? data.landArea * data?.landBuilding * 140 : data.landArea * 140,
              propertyTax: percentageCalculator(data.landRate),
              waterTax: selectedOptionLive === 'yes' ? percentageCalculator(data.landRate) : 0
            })
            break;
      default:
        break;
    }
   
  },[data?.area, data.landArea, data?.landBuilding, data.landRate, selectedOptionLive === 'yes', data?.propertyTax12])

  return (
    <form autoComplete="off" noValidate>
      <Card>
        <CardContent sx={{ pt: 0 }}>
          <Box sx={{ m: -1.5 }}>
            <Grid container spacing={3}>
              <Grid xs={12} md={6}>
                <TextField
                  fullWidth
                  label="First name"
                  name="fname"
                  onChange={(e) => handle.change(e.target.value, "fname")}
                  required
                  value={data.fname}
                  disabled
                />
              </Grid>

              <Grid xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Last name"
                  name="lname"
                  onChange={(e) => handle.change(e.target.value, "lname")}
                  required
                  value={data.lname}
                  disabled
                />
              </Grid>

              <Grid xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Email Address"
                  name="email"
                  onChange={(e) => handle.change(e.target.value, "email")}
                  required
                  value={data.email}
                  disabled
                />
              </Grid>

              <Grid xs={12} md={6}>
                <TextField
                  fullWidth
                  pattern="[789][0-9]{9}"
                  label="Phone Number"
                  name="contact"
                  onChange={(e) => handle.change(e.target.value, "contact")}
                  type="number"
                  value={data.contact}
                  disabled
                />
              </Grid>

              <Grid xs={12} md={4}>
                <FormControl fullWidth>
                  <FormLabel id="demo-row-radio-buttons-group-label">
                    Gender
                  </FormLabel>
                  <RadioGroup
                    fullWidth
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                  >
                    <FormControlLabel
                      value="female"
                      control={<Radio />}
                      label="Female"
                      checked={selectedOption === "female"}
                      disabled
                      onChange={(e) => handle.handleOptionChange(e)}
                    />
                    <FormControlLabel
                      value="male"
                      control={<Radio />}
                      label="Male"
                      checked={selectedOption === "male"}
                      disabled
                      onChange={(e) => handle.handleOptionChange(e)}
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>

              <Grid xs={12} md={4}>
                <FormControl fullWidth>
                  <FormLabel id="demo-row-radio-buttons-group-label">
                    Is Land constructed or not?
                  </FormLabel>
                  <RadioGroup
                    fullWidth
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                  >
                    <FormControlLabel
                      value="yes"
                      control={<Radio />}
                      label="Yes"
                      checked={selectedOptionLive === "yes"}
                      onChange={(e) => handle.handleOptionChangeLive(e)}
                    />
                    <FormControlLabel
                      value="no"
                      control={<Radio />}
                      label="No"
                      checked={selectedOptionLive === "no"}
                      onChange={(e) => handle.handleOptionChangeLive(e)}
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>

              {selectedOptionLive === "yes" ? (
                <Grid xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="No. of floor"
                    name="landBuilding"
                    onChange={(e) =>
                      handle.change(e.target.value, "landBuilding")
                    }
                    type="text"
                    value={data.landBuilding}
                  />
                  <Typography color="error" variant="body2">
                    {validator.message(
                      "Please enter number",
                      data?.landBuilding,
                      "required"
                    )}
                  </Typography>
                </Grid>
              ) : null}

              <Grid xs={12} md={4}>
                <FormControl fullWidth>
                  <FormLabel id="demo-row-radio-buttons-group-label">
                    Type
                  </FormLabel>
                  <RadioGroup
                    fullWidth
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                  >
                    <FormControlLabel
                      value="Rural"
                      control={<Radio />}
                      label="Rural"
                      checked={selectedOptionVillageType === "Rural"}
                      onChange={(e) => handle.handleOptionChangeVillageType(e)}
                    />
                    <FormControlLabel
                      value="Urban"
                      control={<Radio />}
                      label="Urban"
                      checked={selectedOptionVillageType === "Urban"}
                      onChange={(e) => handle.handleOptionChangeVillageType(e)}
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>
              <Grid xs={12} md={4}>
                <FormControl variant="standard" fullWidth>
                  <InputLabel id="demo-simple-select-label">Area</InputLabel>
                  <Select
                    labelId="area"
                    id="demo-simple-select"
                    value={data.area}
                    label="area"
                    onChange={(e) => handle.change(e.target.value, "area")}
                  >
                    <MenuItem value={"Vrudavan Nagar"}>
                      Vrudavan Nagar{" "}
                    </MenuItem>
                    <MenuItem value={"Sambhaji Nagar"}>
                      Sambhaji Nagar{" "}
                    </MenuItem>
                    <MenuItem value={"Mira Nagar"}>Mira Nagar </MenuItem>
                    <MenuItem value={"Ganesh Nagar"}>Ganesh Nagar </MenuItem>
                    <MenuItem value={"Shree Ram Nagar"}>Shree Ram Nagar</MenuItem>
                    <MenuItem value={"Gujar Galli"}>Gujar Galli </MenuItem>
                    <MenuItem value={"Bramhashrushti Colony"}>
                      Bramhashrushti Colony
                    </MenuItem>
                    <MenuItem value={"Mangalmurti Nagar"}>
                    Mangalmurti Nagar
                    </MenuItem>
                    <MenuItem value={"Mahalaxmi Nagar"}>
                      Mahalaxmi Nagar
                    </MenuItem>
                    <MenuItem value={"Punaji Nagar"}>Punaji Nagar</MenuItem>
                  </Select>
                </FormControl>

                <Typography color="error" variant="body2">
                  {validator.message(
                    "Please enter area",
                    data?.area,
                    "required"
                  )}
                </Typography>
              </Grid>

              {console.log('data?.area', data?.area )}
              <Grid xs={12} md={4}>
                <TextField
                  variant="standard"
                  fullWidth
                  label="Street"
                  name="street"
                  value={data?.street}
                  disabled
                />

                <Typography color="error" variant="body2">
                  {validator.message(
                    "Please enter street",
                    data?.street,
                    "required"
                  )}
                </Typography>
              </Grid>

              <Grid xs={12} md={4}>
                <TextField
                  variant="standard"
                  fullWidth
                  label="Taluka"
                  name="taluka"
                  onChange={(e) => handle.change(e.target.value, "taluka")}
                  type="text"
                  value={data?.taluka}
                  disabled
                />
                <Typography color="error" variant="body2">
                  {validator.message("Taluka", data?.taluka, "required")}
                </Typography>
              </Grid>

              <Grid xs={12} md={4}>
                <TextField
                  variant="standard"
                  fullWidth
                  label="District"
                  name="dist"
                  onChange={(e) => handle.change(e.target.value, "dist")}
                  type="text"
                  value={data?.dist}
                  disabled
                />
                <Typography color="error" variant="body2">
                  {validator.message("District", data?.dist, "required")}
                </Typography>
              </Grid>

              <Grid xs={12} md={4}>
                <TextField
                  variant="standard"
                  fullWidth
                  label="Zip code"
                  pattern="^[0-9]{5}(?:-[0-9]{4})?$"
                  name="zip"
                  onChange={(e) => handle.change(e.target.value, "zip")}
                  type="number"
                  value={data?.zip}
                  disabled
                />
                <Typography color="error" variant="body2">
                  {validator.message(
                    "Zip code",
                    data?.zip,
                    "required|min:4|mix:8"
                  )}
                </Typography>
              </Grid>

              <Grid xs={12} md={4}>
                <FormControl variant="standard" fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Property type
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={data.propertyType}
                    label="Property type"
                    onChange={(e) =>
                      handle.change(e.target.value, "propertyType")
                    }
                  >
                    {/* <MenuItem value={"Tangible"}>Tangible</MenuItem> */}
                    <MenuItem value={"Private "}>Private</MenuItem>
                    <MenuItem value={"Personal"}>Personal</MenuItem>
                    <MenuItem value={"Corporate"}>Corporate</MenuItem>
                    <MenuItem value={"Farm land"}>Farm land</MenuItem>
                  </Select>
                </FormControl>
                <Typography color="error" variant="body2">
                  {validator.message(
                    "Property type",
                    data?.propertyType,
                    "required"
                  )}
                </Typography>
              </Grid>

              <Grid xs={12} md={4}>
                <FormControl variant="standard" fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Type of ownership
                  </InputLabel>
                  <Select
                    labelId="Type of ownership"
                    id="demo-simple-select"
                    value={data.type_of_ownership}
                    label="Type of ownership"
                    onChange={(e) =>
                      handle.change(e.target.value, "type_of_ownership")
                    }
                  >
                    <MenuItem value={"Individual"}>Individual</MenuItem>
                    <MenuItem value={"Joint "}>Joint </MenuItem>
                    <MenuItem value={"Coparcenary"}>Coparcenary</MenuItem>
                    <MenuItem value={"Fractional"}>Fractional</MenuItem>
                  </Select>
                </FormControl>

                {/*  <TextField
                  fullWidth
                  label="Type of ownershop"
                  name="type_of_ownership"
                  onChange={(e) => handle.change(e.target.value, 'type_of_ownership')}
                  value={data.type_of_ownership}
                /> */}
              </Grid>

              <Grid xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Property area (in sq.ft)"
                  name="landArea"
                  onChange={(e) => handle.change(e.target.value, "landArea")}
                  value={data.landArea}
                  
                />
                <Typography color="error" variant="body2">
                  {validator.message(
                    "property area",
                    data?.landArea,
                    "required|numeric"
                  )}
                </Typography>
              </Grid>

              <Grid xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Property Amount"
                  name="landRate"
                  onChange={(e) => handle.change(e.target.value, "landRate")}
                  value={data.landRate}
                  disabled
                />
                <Typography color="error" variant="body2">
                  {validator.message(
                    "Property Amount",
                    data?.landRate,
                    "required"
                  )}
                </Typography>
              </Grid>
           
            </Grid>
          </Box>
        </CardContent>
        <Divider />
        <CardActions sx={{ justifyContent: "flex-end" }}>
          <Button variant="contained" onClick={(e) => handle.handleRegister(e)}>
            Save
          </Button>
        </CardActions>
      </Card>
    </form>
  );
};
