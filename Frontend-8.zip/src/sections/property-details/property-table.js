import PropTypes from 'prop-types';
import { format } from 'date-fns';
import {
  Avatar,
  Box,
  Button,
  Card,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  TextField,
  Typography
} from '@mui/material';
import QRCode from "qrcode";
import { Scrollbar } from 'src/components/scrollbar';
import { getInitials } from 'src/utils/get-initials';
import { useEffect, useRef, useState } from 'react';
import Swal from 'sweetalert2';
import axios from 'axios';
import SimpleReactValidator from 'simple-react-validator';

import { useForceUpdate } from 'src/hooks/use-forceupdate';
import { Edit } from '@material-ui/icons';



export const PropertyTable = (props) => {
  const [validator] = useState(new SimpleReactValidator());

  const [open, setOpen] = useState(false);

  const handleClose = () => {
    setOpen(false);
    setOpenAmmount(false);
    validator.hideMessageFor()
  };

  const forceUpdate = useForceUpdate()

  let {
    count = 0,
    items = [],
    onPageChange = () => { },
    onRowsPerPageChange,
    page = 0,
    rowsPerPage = 0,
    selected = [],
  } = props;

  const [QRflag, setQRFlag] = useState(false);
  const [QRdata, setQRdata] = useState(null);
  const [taxFields, setTaxField] = useState(null);
  const [amountEdit, setAmount] = useState(null);
  const [amountEdiatable, setAmountEdiatable] = useState("");
  const [openAmmount, setOpenAmmount] = useState(false);
  const [value, setValue] = useState({
    propertyTax: '',
    waterTax: ''
  });
  const canvasRef = useRef();

  let is_admin = localStorage.getItem('is_admin')

  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: null,
  });

  const handleQRGenerate = (property) => {
    setQRFlag(true)
    setQRdata(property)
  }

  const handleQRStatusUpdate = (property) => {
    axios.put(`http://localhost:8080/qrflag-update/${property?.id}`,
      {
        qrFlag: 'Success'
      })
      .then(res => {
        Swal.fire({
          timer: 1500,
          showConfirmButton: false,
          willOpen: () => {
            Swal.showLoading();
          },
          willClose: () => {
            Swal.fire({
              icon: 'success',
              title: 'QR code activated.',
              showConfirmButton: false,
              timer: 2500,
            });
            items?.map((it) => {
              if (res?.data?.id === it?.id) {
                it.qrFlag = res?.data?.qrFlag
              }
              return it
            })
            forceUpdate()
          },
        });
      }).catch(error => {
        Swal.fire({
          timer: 1500,
          showConfirmButton: false,
          willOpen: () => {
            Swal.showLoading();
          },
          willClose: () => {
            Swal.fire({
              icon: 'error',
              title: 'Error!',
              text: error?.response?.data,
              showConfirmButton: true,
            });
          },
        });
      })
  }

  const handleAddTax = (property) => {
    setOpen(true);
    setTaxField(property)
  }

  const handleEditAmount = (property) => {
    setOpenAmmount(true);
    setAmountEdiatable(property)
  }

  const payNow = (data) => {
    axios.put(`http://localhost:8080/status-update/${data?.id}`,
      {
        status: 'Paid'
      })
      .then(res => {
        axios.post(`http://localhost:8080/sendMailPay`, {
          userEmail: res?.data?.email,
          name: res?.data?.fname + ' ' + res?.data?.lname,
          contact: res?.data?.contact,
          area: res?.data?.area,
          street: res?.data?.street,
          taluka: res?.data?.taluka,
          dist: res?.data?.dist,
          zip: res?.data?.zip,
          propertyTax: res?.data?.propertyTax,
          waterTax: res?.data?.waterTax,
          landArea: res?.data?.landArea,
          landRate: res?.data?.landRate,
          status: res?.data?.status,
        })

        setQRFlag(false)
        setQRdata(res?.data)

        Swal.fire({
          timer: 1500,
          showConfirmButton: false,
          willOpen: () => {
            Swal.showLoading();
          },
          willClose: () => {
            Swal.fire({
              icon: 'success',
              title: 'Thank you for your payment.',
              showConfirmButton: false,
              timer: 2500,
            });
            items?.map((it) => {
              if (res?.data?.id === it?.id) {
                it.status = res?.data?.status
              }
              return it
            })
            forceUpdate()
          },
        });
      }).catch(error => {
        Swal.fire({
          timer: 1500,
          showConfirmButton: false,
          willOpen: () => {
            Swal.showLoading();
          },
          willClose: () => {
            Swal.fire({
              icon: 'error',
              title: 'Error!',
              text: error?.response?.data,
              showConfirmButton: true,
            });
          },
        });
      })
  }

  const handleChange = (values, name) => {
    setValue({
      ...value,
      [name]: values
    })
  }

  const handleChangeAmount = (values, name) => {
    setAmountEdiatable({
      ...amountEdiatable,
      [name]: values
    })
  }
  const handleAppliedTex = (property) => {
          axios.post(`http://localhost:8080/sendMail`, {
            userEmail: property?.email,
            name: property?.fname + ' ' + property?.lname,
            contact: property?.contact,
            area: property?.area,
            street: property?.street,
            taluka: property?.taluka,
            dist: property?.dist,
            zip: property?.zip,
            propertyTax: property?.propertyTax,
            waterTax: property?.waterTax,
            landArea: property?.landArea,
            landRate: property?.landRate,
            status: property?.status,
          }).then((res)=> {
              console.log('res');
            Swal.fire({
              timer: 1500,
              showConfirmButton: false,
              willOpen: () => {
                Swal.showLoading();
              },
              willClose: () => {
                Swal.fire({
                  icon: 'success',
                  title: 'Property details confirmation',
                  showConfirmButton: false,
                  timer: 1500,
                });
                // items?.map((it) => {
                //   if (res?.data?.id === it?.id) {
                //     it.propertyTax = res?.data?.propertyTax,
                //       it.waterTax = res?.data?.waterTax
                //   }
                //   return it
                // })
                forceUpdate()
              },
            });
          }).catch(error => {
          Swal.fire({
            timer: 1500,
            showConfirmButton: false,
            willOpen: () => {
              Swal.showLoading();
            },
            willClose: () => {
              Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: error?.response?.data,
                showConfirmButton: true,
              });

            },
          });
        })
    }

  const handleEditAmountBtn = () => {
      axios.put(`http://localhost:8080/amount-update/${amountEdiatable?.id}`, {"landRate": amountEdiatable?.landRate})
        .then(res => {
          handleClose();
          setAmountEdiatable(null)
          Swal.fire({
            timer: 1500,
            showConfirmButton: false,
            willOpen: () => {
              Swal.showLoading();
            },
            willClose: () => {
              Swal.fire({
                icon: 'success',
                title: 'Property Amount Update ',
                showConfirmButton: false,
                timer: 1500,
              });
              items?.map((it) => {
                if (res?.data?.id === it?.id) it.landRate = res?.data?.landRate
              })
              forceUpdate()
            },
          });
        }).catch(error => {
          Swal.fire({
            timer: 1500,
            showConfirmButton: false,
            willOpen: () => {
              Swal.showLoading();
            },
            willClose: () => {
              Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: error?.response?.data,
                showConfirmButton: true,
              });

            },
          });
        })
  }

  useEffect(() => {
    if (QRflag) {
      let finalQRdata = [{
        "Name": QRdata?.fname + ' ' + QRdata?.lname,
        "Email": QRdata?.email,
        "Contact": QRdata?.contact,
        "Gender": QRdata?.gender.charAt(0).toUpperCase() + QRdata?.gender.slice(1),
        "Area": QRdata?.area,
        "Street": QRdata?.street,
        "District": QRdata?.dist,
        "Taluka": QRdata?.taluka,
        "Zip Code": QRdata?.zip,
        "Type": QRdata?.villageType,
        "Property Type": QRdata?.propertyType,
        "Ownership": QRdata?.ownership,
        "Property Amount": QRdata?.landRate,
        "Property Area  (sq.ft)": QRdata?.landArea,
        "Property Tax": QRdata?.propertyTax,
        "Water Tax": QRdata?.waterTax,
        "Tax Payment Status": QRdata?.status,
        "Land Constracuted or not": QRdata?.liveProperty.charAt(0).toUpperCase() + QRdata.liveProperty.slice(1),
        "No. of floor": QRdata?.landBuilding,
      }]
      finalQRdata = [...finalQRdata]
      QRCode.toDataURL(
        canvasRef.current,
        // QR code doesn't work with an empty string
        // so we are using a blank space as a fallback
        JSON.stringify(finalQRdata, null, 2) || " ",

        (error) => error && console.error(error)
      );
    }
  }, [QRdata]);
  console.log('taxFields', taxFields);
  return (
    <Card>
      <Scrollbar>
        <Box sx={{ minWidth: 1200 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  Registation Id
                </TableCell>
                <TableCell>
                  First Name
                </TableCell>
                <TableCell>
                  Last Name
                </TableCell>
                <TableCell>
                  Email
                </TableCell>
                <TableCell>
                  Phone
                </TableCell>
                <TableCell>
                  Gender
                </TableCell>
                <TableCell>
                  Area
                </TableCell>
                <TableCell>
                  Street
                </TableCell>
                <TableCell>
                  Taluka
                </TableCell>
                <TableCell>
                  District
                </TableCell>
                <TableCell>
                  Zip Code
                </TableCell>
                <TableCell>
                  Type
                </TableCell>
                <TableCell>
                  Property Type
                </TableCell>
                <TableCell>
                  Property Amount
                </TableCell>
                <TableCell>
                  Property Area (sq.ft)
                </TableCell>
                <TableCell>
                  Property Tax
                </TableCell>
                <TableCell>
                  Water Tax
                </TableCell>
                <TableCell>
                  Is Land constructed or not? 
                  </TableCell>
                <TableCell>
                  No. of floor
                </TableCell>
                <TableCell>
                  Tax Payment Status
                </TableCell>
                <TableCell>
                  Created At
                </TableCell>
                {is_admin === 'true' ?
                  <TableCell>
                    Add Tax
                  </TableCell>
                  : null}
                {is_admin === 'false' ?
                  <TableCell>
                    Pay
                  </TableCell>
                  : null}
                <TableCell>
                  QR Code
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {items.map((customer) => {
                const isSelected = selected.includes(customer.id);
                const createdAt = format(new Date(customer?.createdAt), 'dd/MM/yyyy hh:mm:ss');
                return (
                  <TableRow
                    hover
                    key={customer.id}
                    selected={isSelected}
                  >
                    <TableCell>
                      {customer.id}
                    </TableCell>
                    <TableCell>
                      <Stack
                        alignItems="center"
                        direction="row"
                        spacing={2}
                      >
                        {/*   <Avatar src={customer.avatar}>
                          {getInitials(customer.fname)}
                        </Avatar> */}
                        <Typography variant="subtitle2">
                          {customer.fname}
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell>
                      {customer.lname}
                    </TableCell>
                    <TableCell>
                      {customer.email}
                    </TableCell>
                    <TableCell>
                      {customer.contact}
                    </TableCell>
                    <TableCell>
                      {customer.gender.charAt(0).toUpperCase() + customer.gender.slice(1)}
                    </TableCell>
                    <TableCell>
                      {customer.area}
                    </TableCell>
                    <TableCell>
                      {customer.street}
                    </TableCell>
                    <TableCell>
                      {customer.taluka}
                    </TableCell>
                    <TableCell>
                      {customer.dist}
                    </TableCell>
                    <TableCell>
                      {customer.zip}
                    </TableCell>
                    <TableCell>
                      {customer.villageType}
                    </TableCell>
                    <TableCell>
                      {customer.propertyType}
                    </TableCell>
                    <TableCell>
                      {formatter.format(customer.landRate)}
                      {/* <IconButton >
                        <Edit onClick={()=> handleEditAmount(customer)}/>
                      </IconButton> */}
                    </TableCell>
                    
                    <TableCell>
                      {customer.landArea}
                    </TableCell>
                    <TableCell>
                      {customer.propertyTax ?
                        formatter.format(customer.propertyTax)
                        : '-'}
                    </TableCell>
                    <TableCell>
                      {customer.waterTax ?
                        formatter.format(customer.waterTax) :
                        '-'}
                    </TableCell>
                    <TableCell>
                      {customer.liveProperty?.charAt(0).toUpperCase() + customer.liveProperty.slice(1)}
                    </TableCell>
                    <TableCell>
                      {customer.landBuilding}
                    </TableCell>
                    <TableCell>
                      {customer.status}
                    </TableCell>
                    <TableCell>
                      {createdAt}
                    </TableCell>
                    {customer.status === 'Pending' && is_admin === 'false' && (customer?.propertyTax || customer?.waterTax) ?
                      <TableCell sx={{ cursor: 'pointer' }}>
                        <Button variant="outlined" onClick={() => payNow(customer)}>
                          Pay Now
                        </Button>
                      </TableCell>
                      : is_admin === 'false' ? <TableCell>
                        -
                      </TableCell> :
                        customer.status === 'Pending' ?
                          <TableCell>
                            <Button variant="outlined" onClick={() => handleAppliedTex(customer)}>
                               Send Details
                            </Button>
                          </TableCell>
                          : <TableCell>
                            -
                          </TableCell>
                    }
                    {is_admin === 'true' ?
                      <TableCell
                        sx={{ cursor: 'pointer' }}>
                        <Button variant="outlined" onClick={() => handleQRStatusUpdate(customer)}>
                          Generate QR
                        </Button>
                      </TableCell>
                      :
                      customer.qrFlag === 'Success' ?
                        <TableCell
                          sx={{ cursor: 'pointer' }}>
                          <Button variant="outlined" onClick={() => handleQRGenerate(customer)}>
                            View QR Code
                          </Button>
                        </TableCell>
                        : <TableCell>
                          -
                        </TableCell>}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Box>
      </Scrollbar>
      {/*  <TablePagination
        component="div"
        count={count}
        onPageChange={onPageChange}
        onRowsPerPageChange={onRowsPerPageChange}
        page={page}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={[5, 10, 25]}
      />
 */}

      <Dialog open={open} onClose={handleClose} fullWidth>
        <DialogTitle>Add Property Tax</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Property Tax"
            name="propertyTax"
            onChange={(e) => handleChange(e.target.value, 'propertyTax')}
            required
            variant="standard"
          />
          <Typography
            color="error"
            variant="body2"
          >
            {/* {validator.message('Property Tax amount', value?.propertyTax, 'required|numric')} */}
          </Typography>
          <TextField
            fullWidth
            label="Water Tax"
            name="waterTax"
            onChange={(e) => handleChange(e.target.value, 'waterTax')}
            required
            variant="standard"
          />
          <Typography
            color="error"
            variant="body2"
          >
            {/* {validator.message('Water Tax amount', value?.waterTax, 'required|numric')} */}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={() => handleAppliedTex()}>Add Tax</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={openAmmount} onClose={handleClose} fullWidth>
        <DialogTitle>Update amount</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Property Amount"
            name="landRate"
            onChange={(e) => handleChangeAmount(e.target.value, 'landRate')}
            required
            variant="standard"
            value={amountEdiatable?.landRate}
          />
          <Typography
            color="error"
            variant="body2"
          >
            {validator.message('Enter proper amount', amountEdiatable?.landRate, 'required|numric')}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={() => handleEditAmountBtn()}>Update</Button>
        </DialogActions>
      </Dialog>
      {QRflag ?
        <Box sx={{ minWidth: 1200 }}>
          <Stack spacing={3}>
            <Typography align="center"
              color="inherit"
              sx={{
                fontSize: '24px',
                lineHeight: '32px',
                mb: 1
              }}
              variant="h1">
              QR code for {QRdata?.fname + ' ' + QRdata?.lname}
            </Typography>
          </Stack>

          <div align='center'>
            <canvas ref={canvasRef} />
            {is_admin === 'true' &&
              <Box sx={{ minWidth: 800 }}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>
                        Registation Id
                      </TableCell>
                      <TableCell>
                        First Name
                      </TableCell>
                      <TableCell>
                        Last Name
                      </TableCell>
                      <TableCell>
                        Email
                      </TableCell>
                      <TableCell>
                        Phone
                      </TableCell>
                      <TableCell>
                        Gender
                      </TableCell>
                      <TableCell>
                        Area
                      </TableCell>
                      <TableCell>
                        Street
                      </TableCell>
                      <TableCell>
                        Taluka
                      </TableCell>
                      <TableCell>
                        District
                      </TableCell>
                      <TableCell>
                        Zip Code
                      </TableCell>
                      <TableCell>
                        Type
                      </TableCell>
                      <TableCell>
                        Property Type
                      </TableCell>
                      <TableCell>
                        Property Amount
                      </TableCell>
                      <TableCell>
                        Property Area  (sq.ft)
                      </TableCell>
                      <TableCell>
                        Property Tax
                      </TableCell>
                      <TableCell>
                        Water Tax
                      </TableCell>
                      <TableCell>
                      Is Land constructed or not? 
                      </TableCell>
                      <TableCell>
                       No. of floor
                      </TableCell>
                      <TableCell>
                        Tax Payment Status
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableCell>
                      {customer.id}
                    </TableCell>
                    <TableRow
                      hover
                      key={QRdata.id}
                    >
                      <TableCell>
                        <Stack
                          alignItems="center"
                          direction="row"
                          spacing={2}
                        >
                          {/*     <Avatar>
                            {getInitials(QRdata.fname)}
                          </Avatar> */}
                          <Typography variant="subtitle2">
                            {QRdata.fname}
                          </Typography>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        {QRdata.lname}
                      </TableCell>
                      <TableCell>
                        {QRdata.email}
                      </TableCell>
                      <TableCell>
                        {QRdata.contact}
                      </TableCell>
                      <TableCell>
                        {QRdata.gender.charAt(0).toUpperCase() + QRdata.gender.slice(1)}
                      </TableCell>
                      <TableCell>
                        {QRdata.area}
                      </TableCell>
                      <TableCell>
                        {QRdata.street}
                      </TableCell>
                      <TableCell>
                        {QRdata.taluka}
                      </TableCell>
                      <TableCell>
                        {QRdata.dist}
                      </TableCell>
                      <TableCell>
                        {QRdata.zip}
                      </TableCell>
                      <TableCell>
                        {QRdata.villageType}
                      </TableCell>
                      <TableCell>
                        {QRdata.propertyType}
                      </TableCell>
                      <TableCell>
                        {QRdata.landRate}
                      </TableCell>
                      <TableCell>
                        {QRdata.landArea}
                      </TableCell>
                      <TableCell>
                        {QRdata.propertyTax ?
                          formatter.format(QRdata.propertyTax)
                          : '-'}
                      </TableCell>
                      <TableCell>
                        {QRdata.waterTax ?
                          formatter.format(QRdata.waterTax) :
                          '-'}
                      </TableCell>
                      <TableCell>
                        {QRdata.liveProperty?.charAt(0).toUpperCase() + QRdata.liveProperty.slice(1)}
                      </TableCell>
                      <TableCell>
                        {QRdata.landBuilding}
                      </TableCell>
                      <TableCell>
                        {QRdata.status}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </Box>
            }
          </div>
        </Box>
        : null}
    </Card>
  );
};

PropertyTable.propTypes = {
  count: PropTypes.number,
  items: PropTypes.array,
  onPageChange: PropTypes.func,
  onRowsPerPageChange: PropTypes.func,
  page: PropTypes.number,
  rowsPerPage: PropTypes.number,
  selected: PropTypes.array
};
