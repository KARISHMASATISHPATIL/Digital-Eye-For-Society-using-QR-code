import { useEffect, useState } from 'react';
import { Visibility, VisibilityOff } from '@material-ui/icons';
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  IconButton,
  InputAdornment,
  CardHeader,
  Divider,
  TextField,
  Radio,
  Unstable_Grid2 as Grid,
  FormControl,
  FormLabel,
  FormControlLabel,
  RadioGroup,
  Typography
} from '@mui/material';
import Swal from 'sweetalert2';
import axios from 'axios';
import { useRouter } from 'next/navigation';
import SimpleReactValidator from 'simple-react-validator';
import { useForceUpdate } from 'src/hooks/use-forceupdate';


export const AccountProfileDetails = () => {


  const [ShwoPass, setShowPass] = useState(false);


  const forceUpdate = useForceUpdate()
  const [data, setData] = useState({
    fname: '', lname: '', email: '', contact: '', password: '', gender: ''
  })
  const logingFlag = localStorage.getItem('logingFlag')

  const [validator] = useState(new SimpleReactValidator());
  const router = useRouter();

  const [selectedOption, setSelectedOption] = useState('male');

  const [passError, setPassError] = useState(false);
  const passRegex = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;

  const showPassword = () => {
    setShowPass(!ShwoPass)
  }

  const validate = () => {
    if (!passRegex?.test(data?.password)) {
      setPassError(true)
    } else {
      setPassError(false)
    }
  }

  useEffect(() => {
    if (data?.password && passRegex?.test(data?.password)) {
      setPassError(false)
    }
  }, [data?.password])

  console.log('passError', passError);

  useEffect(() => {
    return (() => {
      console.log('performance.navigation', performance.navigation);
      if (window.performance) {
        if (performance.navigation.type == 1 && !logingFlag) {
          localStorage.removeItem('loginFlag');
          router.push('/auth/login')
        }
      }
    })
  }, [])

  const handle = {
    change: (value, name) => {
      setData({
        ...data,
        [name]: value
      })
    },
    handleOptionChange: (e) => {
      setSelectedOption(e.target.value);
    },
    handleRegister(e) {
      e.preventDefault();
      if (validator.allValid()) {
        let param = {
          ...data,
          gender: selectedOption
        }
        console.log('param', param);
        axios.post(`http://localhost:8080/register`, param)
          .then(res => {
            Swal.fire({
              timer: 1500,
              showConfirmButton: false,
              willOpen: () => {
                Swal.showLoading();
              },
              willClose: () => {
                Swal.fire({
                  icon: 'success',
                  title: 'User Registration Successful!',
                  showConfirmButton: false,
                  timer: 1500,
                });
              },
            });
            router.push('/auth/login');
            localStorage.removeItem('logingFlag')
            validator.hideMessages();
            setData({
              fname: '', lname: '', email: '', contact: '', password: '', gender: ''
            })
          }).catch(error => {
            Swal.fire({
              timer: 1500,
              showConfirmButton: false,
              willOpen: () => {
                Swal.showLoading();
              },
              willClose: () => {
                Swal.fire({
                  icon: 'error',
                  title: 'Error!',
                  text: error?.response?.data,
                  showConfirmButton: true,
                });
              },
            });
          })
      } else {
        validator.showMessages();
        forceUpdate();
      }
    }
  }

  return (
    <form
      autoComplete="off"
      noValidate
    >
      <Card>
        <CardContent sx={{ pt: 0 }}>
          <Box sx={{ m: -1.5 }}>
            <Grid
              container
              spacing={3}
            >
              <Grid
                xs={12}
                md={6}
              >
                <TextField
                  fullWidth
                  label="First name"
                  name="fname"
                  onChange={(e) => handle.change(e.target.value, 'fname')}
                  required
                  value={data.fname}
                />
                <Typography
                  color="error"
                  variant="body2"
                >
                  {validator.message('First name', data?.fname, 'required')}
                </Typography>
              </Grid>
              <Grid
                xs={12}
                md={6}
              >
                <TextField
                  fullWidth
                  label="Last name"
                  name="lname"
                  onChange={(e) => handle.change(e.target.value, 'lname')}
                  required
                  value={data.lname}
                />
                <Typography
                  color="error"
                  variant="body2"
                >
                  {validator.message('Last Name', data?.lname, 'required')}
                </Typography>

              </Grid>
              <Grid
                xs={12}
                md={6}
              >
                <TextField
                  fullWidth
                  label="Email Address"
                  name="email"
                  onChange={(e) => handle.change(e.target.value, 'email')}
                  required
                  value={data.email}
                />
                <Typography
                  color="error"
                  variant="body2"
                >
                  {validator.message('email', data?.email, 'required|email')}
                </Typography>

              </Grid>

              <Grid
                xs={12}
                md={6}
              >
                <TextField
                  fullWidth
                  label="Password"
                  name="password"

                  onChange={(e) => {
                    handle.change(e.target.value, 'password');
                    validate();
                  }}
                  value={data.password}

                  type={!ShwoPass ? "password" : "text"}

                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={showPassword} edge="end">
                          {!ShwoPass ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}



                />
                {passError ?
                  <Typography
                    color="error"
                    variant="body2"
                  >
                    Password must contain at least uppercase, lowercase, special character and digit
                  </Typography>
                  : null}
              </Grid>

              <Grid
                xs={12}
                md={6}
              >
                <TextField
                  fullWidth
                  pattern="[789][0-9]{9}"
                  label="Phone Number"
                  name="contact"
                  onChange={(e) => handle.change(e.target.value, 'contact')}
                  value={data.contact}
                />
                <Typography
                  color="error"
                  variant="body2"
                >
                  {validator.message('phone', data?.password, 'required')}
                </Typography>
              </Grid>
              <Grid
                xs={12}
                md={6}
              >
                <FormControl>
                  <FormLabel id="demo-row-radio-buttons-group-label">Gender</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                  >
                    <FormControlLabel value="female" control={<Radio />} label="Female"
                      checked={selectedOption === 'female'}
                      onChange={(e) => handle.handleOptionChange(e)} />
                    <FormControlLabel value="male" control={<Radio />} label="Male"
                      checked={selectedOption === 'male'}
                      onChange={(e) => handle.handleOptionChange(e)} />
                  </RadioGroup>
                </FormControl>
              </Grid>
            </Grid>
          </Box>
        </CardContent>
        <Divider />
        <CardActions sx={{ justifyContent: 'flex-end' }}>
          <Button variant="contained" onClick={(e) => handle.handleRegister(e)}>
            Save User deatils
          </Button>
        </CardActions>
      </Card>
    </form>
  );
};
